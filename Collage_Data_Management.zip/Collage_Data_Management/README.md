# Collage Management System In Java
## Features

 * Common Features 
      * Cources Management
      * Subjects Management
      * Students Management
      * Faculties Management
      * Students Attandance Management
      * Student Marks Management
 * Advance Features 🔥
      * Rollnumber Generator
      * Chatting
          * Message delivered
          * Unseen messages
          * Notification
          * Group chatting
      * Photo view of Students and Faculties
      * Student or Faculty login history
      * Download Marksheet
      * Notification
      * Declare result

* Dashboard UI : Java Swing
* Database  : Mysql


## Installation

* Import this project in your IDE
* Create new Database and set name as 'collagedata' after that import 'collagedata.sql' file (Attached with this folder) in this database.

## Database Connection

* I have used following 👇 data for database connection
    * url="jdbc:mysql://localhost:3306/collagedata";
    * user name="root";
    * password="";

* If you want to change this data then open ".\src\collageapplication\common\DataBaseConnection.java"


## How to Run 

* Start Database Server
* Start Chat Server
* Run the application
    * You can run application in two ways
         1) Open Collage Management System.jar which i have attached in this folder  or
         2) Open "src/collageapplication/login/LoginPageFrame.java" Run this file

 * Admin userid : info@heraldcollege.edu.np
 * Admin password  : admin
 * Faculty userid  : Faculty id
 * Student Userid  : cource-sem-rollnumber (BIT-2021-3-16) password :2021       


